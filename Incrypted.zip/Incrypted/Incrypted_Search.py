from requests_html import HTMLSession
import telebot
import csv
import time

full_list = []
API_KEY = '6521249603:AAEzP7FpWkPxAaCP055G8WmZKMR8nvPVNfQ'
bot = telebot.TeleBot(API_KEY)
chat_id = '-1001832486733'
session = HTMLSession()
r = session.get('https://incrypted.com/airdrops/')
titles = r.html.find('.airdrops-row')

# Парсим сайт и собираем нужные данные в список full_list
for title in titles:
    new_list = (title.text).split('\n')
    new_list.append(title.absolute_links.pop())
    full_list.append(new_list)
    print(new_list)


try:
    with open('Aidrop.csv', 'r', newline='') as file:
        reader = csv.reader(file, delimiter=';')
        data = [row[0] for row in reader]  # Создаем список только из первых значений

    with open('Aidrop.csv', 'a', newline='') as file:
        writer = csv.writer(file, delimiter=';')
        for item in full_list:
            if item[0] not in data:
                writer.writerow(item)
                Project_name = str(item[0])
                Reward = str(item[2])
                Date = str(item[3])
                Activity = str(item[4])
                logo = item[-1]
                message = f'*Project_name:* {Project_name}\n*Reward:* {Reward}\n*The date of the:* {Date}\n*Activity Type:* {Activity}\n'
                try:
                    bot.send_photo(chat_id, photo=logo, caption=message + f'[Link to Airdrop]({logo})', parse_mode='Markdown')
                    time.sleep(5)
                except:
                    #pass
                    bot.send_message(chat_id, message + f'[Link to Airdrop]({logo})', parse_mode='Markdown')
                    time.sleep(5)


# Создаем файл если его нет
except FileNotFoundError:
    with open('Aidrop.csv', 'w', newline='') as file:
        pass